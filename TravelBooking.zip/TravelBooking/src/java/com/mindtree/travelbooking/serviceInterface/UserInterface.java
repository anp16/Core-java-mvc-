package com.mindtree.travelbooking.serviceInterface;

import java.util.List;

import org.springframework.stereotype.Service;

import com.mindtree.travelbooking.entity.User;
@Service
public interface UserInterface {

	List<Integer> getAllUserIdList();

	void addUsers(User user);

}
