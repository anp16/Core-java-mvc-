package com.mindtree.travelbooking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TravelBookingApplicationTests {

	@Test
	void contextLoads() {
	}

}
