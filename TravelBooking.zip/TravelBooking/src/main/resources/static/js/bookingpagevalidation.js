/**
 * 
 */
$('#btn').click(function(){
		alert("hello");
var src=$('#source').val();
var regsrc=/^[A-Za-z]*$/;
var issource=true;
if(src=='')
	{
	$('#errsource').show();
	$('#errsource').text("cant be empty");
	issource=false;
	}
if(!regsrc.test(src))
	{
	
	$('#errsource').show();
	$('#errsource').text("only alphabets");
	issource=false;
	}
	
var des=$('#destination').val();
var regdes=/^[A-Za-z]*$/;
var isdestination=true;
if(des=='')
	{
	$('#errdestination').show();
	$('#errdestination').text("cant be empty");
	isdestination=false;
	}
else if(!regdes.test(des))
	{
	
	$('#errdestination').show();
	$('#errdestination').text("only alphabets");
	isdestination=false;
	}
var dis=$('#distance').val();
var isdistance=true;
if(dis=='')
	{
	$('#errdistance').show();
	$('#errdistance').text("cant be 0");
	isdistance=false;
	}
else if(dis<200)
	{
	
	$('#errdistance').show();
	$('#errdistance').text("cant be less than 200");
	isdistance=false;
	}
var food=$("input[type=radio]:checked").val();
if(!food)
	{
	$('#errfoodtype').show();
	$('#errfoodtype').text("choose one");
	
	}
var count=$('input:checkbox:checked').length;
var ischeck=true;
if(count<1)
	{
	$('#errcheck').show();
	$('#errcheck').text("choose atleast one");
	ischeck=false;
	}
	
	if(issource && isdestination && isdistance && food && ischeck )
		{
		return true;
		}
	else
		{
		return false;	
		}
	
	
		});
		
		
		