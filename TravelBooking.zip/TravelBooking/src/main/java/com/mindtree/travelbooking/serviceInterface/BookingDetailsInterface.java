package com.mindtree.travelbooking.serviceInterface;

import java.util.List;

import org.springframework.stereotype.Service;

import com.mindtree.travelbooking.entity.BookingDetails;
@Service

public interface BookingDetailsInterface {

	void addBookingDetails(BookingDetails bookingDetails, int userId);

	BookingDetails getBookingDetailsById(int bookingId);

	void editByBookingId(BookingDetails bookingDetails, int bookingId);

	

}
