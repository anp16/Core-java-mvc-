package com.mindtree.travelbooking.serviceInterface.service;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.mindtree.travelbooking.entity.User;
import com.mindtree.travelbooking.repository.UserRepository;
import com.mindtree.travelbooking.serviceInterface.UserInterface;
@Service
public class UserImpli implements UserInterface {
	@Autowired
	private UserRepository userRepository;

	@Override
	public List<Integer> getAllUserIdList() {
		List<User> userList = userRepository.findAll();
		List<Integer> userId = new ArrayList<Integer>();
		for (User user : userList) {
			userId.add(user.getUserId());
		}
		return userId;
	}

	@Override
	public void addUsers(User user) {
		userRepository.save(user);
		
	}

	@Override
	public User getUserById(Integer userId) {
		
		return userRepository.findById(userId).get();
	}
		
		
	}

	
	


