package com.mindtree.travelbooking.serviceInterface.service;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.mindtree.travelbooking.entity.BookingDetails;
import com.mindtree.travelbooking.entity.User;
import com.mindtree.travelbooking.repository.BookingDetailsRepository;
import com.mindtree.travelbooking.repository.UserRepository;
import com.mindtree.travelbooking.serviceInterface.BookingDetailsInterface;

@Service

public class BookingDetailsImpli implements BookingDetailsInterface {
	@Autowired
	private BookingDetailsRepository bookingDetailsRepository;
	@Autowired
	private UserRepository userRepository;

	@Override
	public void addBookingDetails(BookingDetails bookingDetails, int userId) {
		User user = userRepository.findById(userId).get();
		bookingDetails.setUser(user);
		int price=(bookingDetails.getJourneyDistance()*10);
		if(user.getUserAge()>30 && user.getUserAge()<60)
		{
			price=(int) (price-(price*0.05));
			bookingDetails.setPrice(price);
		}
		if(user.getUserAge()>60)
		{
			price=(int) (price-(price*0.1));
			bookingDetails.setPrice(price);
		}
		if(user.getUserAge()<30)
		{
			bookingDetails.setPrice(price);
		}
		bookingDetailsRepository.save(bookingDetails);
	}


	@Override
	public BookingDetails getBookingDetailsById(int BookingId) {
		return bookingDetailsRepository.findById(BookingId).get();

	}

	@Override
	public void editByBookingId(BookingDetails bookingDetails, int bookingId) {
		BookingDetails bd = bookingDetailsRepository.findById(bookingId).orElse(bookingDetails);
		bd.setSource(bookingDetails.getSource());
		bd.setDestination(bookingDetails.getDestination());
		bd.setJourneyDate(bookingDetails.getJourneyDate());
		bd.setJourneyDistance(bookingDetails.getJourneyDistance());
		bd.setFoodPreferences(bookingDetails.getFoodPreferences());
		bd.setTravelingWith(bookingDetails.getTravelingWith());
		bookingDetailsRepository.save(bd);

	}


}
